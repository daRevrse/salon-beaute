/usr/bin/bash: line 1: mysqldump: command not found
