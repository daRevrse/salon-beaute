module.exports = {
  apps: [{
    name: 'salon-beaute-api',
    cwd: '/var/www/salon-beaute/backend',
    script: 'server.js',
    instances: 1,
    exec_mode: 'fork',
    env: {
      NODE_ENV: 'production',
      PORT: 3001
    },
    error_file: '/var/log/salon-beaute/error.log',
    out_file: '/var/log/salon-beaute/out.log',
    log_date_format: 'YYYY-MM-DD HH:mm:ss',
    watch: false,
    autorestart: true,
    max_restarts: 10,
    restart_delay: 4000,
    min_uptime: '10s',
    max_memory_restart: '500M'
  }]
};
