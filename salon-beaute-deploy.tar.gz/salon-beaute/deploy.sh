#!/bin/bash

##############################################
# Script de Déploiement Automatique
# Salon de Beauté - Application Fullstack
##############################################

set -e  # Arrêter en cas d'erreur

# Couleurs pour les messages
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Variables de configuration
APP_NAME="salon-beaute"
APP_DIR="/var/www/${APP_NAME}"
BACKEND_PORT=3001
DOMAIN="salon.votredomaine.com"  # À MODIFIER

echo -e "${BLUE}╔══════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║   Déploiement Salon de Beauté sur VPS      ║${NC}"
echo -e "${BLUE}╚══════════════════════════════════════════════╝${NC}"
echo ""

# Vérifier les prérequis
echo -e "${YELLOW}🔍 Vérification des prérequis...${NC}"

# Node.js
if ! command -v node &> /dev/null; then
    echo -e "${RED}❌ Node.js n'est pas installé${NC}"
    exit 1
fi
echo -e "${GREEN}✓ Node.js $(node -v)${NC}"

# NPM
if ! command -v npm &> /dev/null; then
    echo -e "${RED}❌ NPM n'est pas installé${NC}"
    exit 1
fi
echo -e "${GREEN}✓ NPM $(npm -v)${NC}"

# Nginx
if ! command -v nginx &> /dev/null; then
    echo -e "${RED}❌ Nginx n'est pas installé${NC}"
    exit 1
fi
echo -e "${GREEN}✓ Nginx${NC}"

# PM2
if ! command -v pm2 &> /dev/null; then
    echo -e "${YELLOW}⚠️  PM2 n'est pas installé. Installation...${NC}"
    sudo npm install -g pm2
fi
echo -e "${GREEN}✓ PM2${NC}"

echo ""

# Créer les répertoires nécessaires
echo -e "${YELLOW}📁 Création des répertoires...${NC}"
sudo mkdir -p ${APP_DIR}
sudo mkdir -p /var/log/${APP_NAME}
sudo chown -R $USER:$USER ${APP_DIR}
sudo chown -R $USER:$USER /var/log/${APP_NAME}
echo -e "${GREEN}✓ Répertoires créés${NC}"
echo ""

# Copier les fichiers (à adapter selon votre méthode de transfert)
echo -e "${YELLOW}📦 Transfert des fichiers...${NC}"
echo -e "${BLUE}ℹ️  Assurez-vous que les fichiers sont dans ${APP_DIR}${NC}"
echo -e "${BLUE}   Utilisez: scp -r salon-beaute/* user@server:${APP_DIR}/${NC}"
read -p "Appuyez sur Entrée une fois les fichiers transférés..."
echo ""

# Installation Backend
echo -e "${YELLOW}🔧 Installation Backend...${NC}"
cd ${APP_DIR}/backend
npm install --production
echo -e "${GREEN}✓ Backend installé${NC}"
echo ""

# Modification du port backend
echo -e "${YELLOW}⚙️  Configuration du port backend (${BACKEND_PORT})...${NC}"
sed -i "s/const PORT = 3000/const PORT = ${BACKEND_PORT}/" ${APP_DIR}/backend/server.js
echo -e "${GREEN}✓ Port configuré${NC}"
echo ""

# Build Frontend
echo -e "${YELLOW}🎨 Build du Frontend...${NC}"
cd ${APP_DIR}/frontend
npm install
npm run build
echo -e "${GREEN}✓ Frontend buildé${NC}"
echo ""

# Configuration PM2
echo -e "${YELLOW}🔄 Configuration PM2...${NC}"
cd ${APP_DIR}

# Arrêter l'ancienne instance si elle existe
pm2 delete ${APP_NAME}-api 2>/dev/null || true

# Démarrer avec PM2
pm2 start ecosystem.config.js
pm2 save
echo -e "${GREEN}✓ PM2 configuré${NC}"
echo ""

# Configurer le démarrage automatique
echo -e "${YELLOW}🚀 Configuration du démarrage automatique...${NC}"
sudo env PATH=$PATH:/usr/bin pm2 startup systemd -u $USER --hp $HOME
echo -e "${GREEN}✓ Démarrage auto configuré${NC}"
echo ""

# Configuration Nginx
echo -e "${YELLOW}🌐 Configuration Nginx...${NC}"

# Sauvegarder l'ancienne config si elle existe
if [ -f /etc/nginx/sites-available/${APP_NAME} ]; then
    sudo cp /etc/nginx/sites-available/${APP_NAME} /etc/nginx/sites-available/${APP_NAME}.backup
fi

# Copier la nouvelle configuration
sudo cp ${APP_DIR}/nginx.conf /etc/nginx/sites-available/${APP_NAME}

# Remplacer le nom de domaine
sudo sed -i "s/salon.votredomaine.com/${DOMAIN}/" /etc/nginx/sites-available/${APP_NAME}

# Créer le lien symbolique
sudo ln -sf /etc/nginx/sites-available/${APP_NAME} /etc/nginx/sites-enabled/

# Tester la configuration
sudo nginx -t

if [ $? -eq 0 ]; then
    echo -e "${GREEN}✓ Configuration Nginx valide${NC}"
    sudo systemctl reload nginx
    echo -e "${GREEN}✓ Nginx rechargé${NC}"
else
    echo -e "${RED}❌ Erreur dans la configuration Nginx${NC}"
    exit 1
fi
echo ""

# Configuration SSL (optionnel)
echo -e "${YELLOW}🔒 Configuration SSL avec Let's Encrypt${NC}"
read -p "Voulez-vous configurer SSL maintenant? (y/n) " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    # Vérifier si Certbot est installé
    if ! command -v certbot &> /dev/null; then
        echo -e "${YELLOW}Installation de Certbot...${NC}"
        sudo apt update
        sudo apt install -y certbot python3-certbot-nginx
    fi
    
    sudo certbot --nginx -d ${DOMAIN}
    echo -e "${GREEN}✓ SSL configuré${NC}"
fi
echo ""

# Configurer le firewall
echo -e "${YELLOW}🔥 Configuration du firewall...${NC}"
sudo ufw allow 'Nginx Full'
echo -e "${GREEN}✓ Firewall configuré${NC}"
echo ""

# Vérifications finales
echo -e "${YELLOW}🔍 Vérifications finales...${NC}"

# Backend
echo -n "Backend API: "
if curl -s http://localhost:${BACKEND_PORT}/api/health > /dev/null; then
    echo -e "${GREEN}✓ OK${NC}"
else
    echo -e "${RED}✗ ERREUR${NC}"
fi

# PM2
echo -n "PM2: "
if pm2 list | grep -q ${APP_NAME}-api; then
    echo -e "${GREEN}✓ OK${NC}"
else
    echo -e "${RED}✗ ERREUR${NC}"
fi

# Nginx
echo -n "Nginx: "
if sudo systemctl is-active --quiet nginx; then
    echo -e "${GREEN}✓ OK${NC}"
else
    echo -e "${RED}✗ ERREUR${NC}"
fi

echo ""
echo -e "${BLUE}╔══════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║          Déploiement Terminé ! 🎉          ║${NC}"
echo -e "${BLUE}╚══════════════════════════════════════════════╝${NC}"
echo ""
echo -e "${GREEN}✓ Application déployée avec succès !${NC}"
echo ""
echo -e "${YELLOW}📍 Accès à l'application :${NC}"
echo -e "   ${BLUE}http://${DOMAIN}${NC}"
if [[ $REPLY =~ ^[Yy]$ ]]; then
    echo -e "   ${BLUE}https://${DOMAIN}${NC}"
fi
echo ""
echo -e "${YELLOW}🔧 Commandes utiles :${NC}"
echo -e "   ${BLUE}pm2 status${NC}              - Voir l'état"
echo -e "   ${BLUE}pm2 logs${NC}                - Voir les logs"
echo -e "   ${BLUE}pm2 restart ${APP_NAME}-api${NC} - Redémarrer"
echo ""
echo -e "${YELLOW}📊 Monitoring :${NC}"
echo -e "   ${BLUE}pm2 monit${NC}               - Dashboard temps réel"
echo ""
echo -e "${YELLOW}📝 Logs :${NC}"
echo -e "   ${BLUE}/var/log/${APP_NAME}/${NC}      - Logs application"
echo -e "   ${BLUE}/var/log/nginx/${NC}         - Logs Nginx"
echo ""
