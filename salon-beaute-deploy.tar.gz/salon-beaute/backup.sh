#!/bin/bash

##############################################
# Script de Sauvegarde Automatique
# Base de données Salon de Beauté
##############################################

# Configuration
APP_DIR="/var/www/salon-beaute"
BACKUP_DIR="/var/backups/salon-beaute"
DB_FILE="${APP_DIR}/backend/salon.db"
DATE=$(date +%Y%m%d_%H%M%S)
RETENTION_DAYS=7

# Créer le répertoire de sauvegarde
mkdir -p ${BACKUP_DIR}

# Créer la sauvegarde
echo "🔄 Sauvegarde de la base de données..."
cp ${DB_FILE} ${BACKUP_DIR}/salon_${DATE}.db

if [ $? -eq 0 ]; then
    echo "✅ Sauvegarde créée: salon_${DATE}.db"
else
    echo "❌ Erreur lors de la sauvegarde"
    exit 1
fi

# Supprimer les anciennes sauvegardes (garder les N derniers jours)
echo "🧹 Nettoyage des anciennes sauvegardes..."
find ${BACKUP_DIR} -name "salon_*.db" -type f -mtime +${RETENTION_DAYS} -delete

# Afficher les sauvegardes disponibles
echo ""
echo "📁 Sauvegardes disponibles:"
ls -lh ${BACKUP_DIR}/salon_*.db

# Statistiques de la base de données
DB_SIZE=$(du -h ${DB_FILE} | cut -f1)
BACKUP_SIZE=$(du -h ${BACKUP_DIR}/salon_${DATE}.db | cut -f1)

echo ""
echo "📊 Statistiques:"
echo "   Taille DB actuelle: ${DB_SIZE}"
echo "   Taille sauvegarde: ${BACKUP_SIZE}"
echo "   Date: $(date)"
